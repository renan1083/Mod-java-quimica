package com.alquimialab;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Móvel decorativo com hitbox customizada. */
public class FurnitureBlock extends Block {
    public static final MapCodec<FurnitureBlock> CODEC =
        simpleCodec(props -> new FurnitureBlock(props, Shapes.block()));

    private final VoxelShape shape;

    public FurnitureBlock(Properties props, VoxelShape shape) {
        super(props);
        this.shape = shape;
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return shape;
    }
}
