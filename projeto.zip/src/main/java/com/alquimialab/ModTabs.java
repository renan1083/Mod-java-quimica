package com.alquimialab;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
        DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AlquimiaLab.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("principal",
        () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.alquimialab"))
            .icon(() -> new ItemStack(ModBlocks.MESA_ALQUIMIA.get()))
            .displayItems((params, out) -> ModItems.ITEMS.getEntries().forEach(e -> out.accept(e.get())))
            .build());
}
