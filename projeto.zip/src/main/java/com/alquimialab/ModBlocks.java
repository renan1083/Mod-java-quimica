package com.alquimialab;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, AlquimiaLab.MODID);

    private static RegistryObject<Block> furniture(String name, VoxelShape shape) {
        RegistryObject<Block> block = BLOCKS.register(name,
            () -> new FurnitureBlock(BlockBehaviour.Properties.of()
                .mapColor(MapColor.WOOD).strength(2.0F, 3.0F)
                .sound(SoundType.WOOD).noOcclusion(), shape));
        ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }

    public static final RegistryObject<Block> MESA_ALQUIMIA = furniture("mesa_alquimia",
        Shapes.or(
            Block.box(0, 12, 0, 16, 16, 16),
            Block.box(1, 0, 1, 3, 12, 3),
            Block.box(13, 0, 1, 15, 12, 3),
            Block.box(1, 0, 13, 3, 12, 15),
            Block.box(13, 0, 13, 15, 12, 15)));

    public static final RegistryObject<Block> BANCADA_LABORATORIO = furniture("bancada_laboratorio",
        Shapes.or(
            Block.box(1, 0, 1, 15, 13, 15),
            Block.box(0, 13, 0, 16, 16, 16)));

    public static final RegistryObject<Block> ESTANTE_ALQUIMICA = furniture("estante_alquimica",
        Shapes.or(
            Block.box(1, 0, 1, 3, 16, 15),
            Block.box(13, 0, 1, 15, 16, 15),
            Block.box(1, 0, 1, 15, 2, 15),
            Block.box(1, 7, 1, 15, 9, 15),
            Block.box(1, 14, 1, 15, 16, 15)));

    public static final RegistryObject<Block> BANQUETA_ALQUIMISTA = furniture("banqueta_alquimista",
        Shapes.or(
            Block.box(2, 9, 2, 14, 11, 14),
            Block.box(3, 0, 3, 5, 9, 5),
            Block.box(11, 0, 3, 13, 9, 5),
            Block.box(3, 0, 11, 5, 9, 13),
            Block.box(11, 0, 11, 13, 9, 13)));

    public static final RegistryObject<Block> SUPORTE_FRASCOS = furniture("suporte_frascos",
        Shapes.or(
            Block.box(1, 0, 1, 15, 2, 15),
            Block.box(7, 2, 7, 9, 14, 9),
            Block.box(2, 12, 6, 14, 14, 10)));

    public static final RegistryObject<Block> ARMARIO_INGREDIENTES = furniture("armario_ingredientes",
        Block.box(1, 0, 1, 15, 16, 15));

}
