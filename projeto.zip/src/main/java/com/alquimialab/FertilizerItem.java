package com.alquimialab;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Fertilizante que reutiliza a lógica real do farelo de osso (BonemealableBlock),
 * então funciona com plantações, mudas, grama, flores, etc. (inclusive blocos de outros mods).
 */
public class FertilizerItem extends Item {

    public enum Kind {
        //          aplicações, raio, hidrata
        BASICO(1, 0, false),
        POTENTE(3, 0, false),
        VERDEJANTE(1, 1, false),
        HIDRATANTE(1, 1, true);

        final int applications;
        final int radius;
        final boolean moisturizes;

        Kind(int applications, int radius, boolean moisturizes) {
            this.applications = applications;
            this.radius = radius;
            this.moisturizes = moisturizes;
        }
    }

    private final Kind kind;

    public FertilizerItem(Properties props, Kind kind) {
        super(props);
        this.kind = kind;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockPos origin = ctx.getClickedPos();
        ItemStack stack = ctx.getItemInHand();
        Player player = ctx.getPlayer();
        int r = kind.radius;
        boolean used = false;

        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-r, 0, -r), origin.offset(r, 0, r))) {
            BlockPos pos = p.immutable();
            boolean hit = false;

            if (kind.moisturizes) {
                hit |= moisturize(level, pos);
                hit |= moisturize(level, pos.below());
            }
            for (int i = 0; i < kind.applications; i++) {
                // copyWithCount: o método do vanilla consome a pilha, então usamos uma cópia
                if (BoneMealItem.applyBonemeal(stack.copyWithCount(1), level, pos, player)) {
                    hit = true;
                } else {
                    break;
                }
            }
            if (hit) {
                used = true;
                if (level.isClientSide) {
                    BoneMealItem.addGrowthParticles(level, pos, 15);
                }
            }
        }

        if (!used) return InteractionResult.PASS;
        if (!level.isClientSide) stack.consume(1, player);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    private static boolean moisturize(Level level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (state.getBlock() instanceof FarmBlock && state.getValue(FarmBlock.MOISTURE) < 7) {
            if (!level.isClientSide) level.setBlock(pos, state.setValue(FarmBlock.MOISTURE, 7), 2);
            return true;
        }
        return false;
    }
}
