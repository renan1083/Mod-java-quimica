package com.alquimialab;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AlquimiaLab.MODID)
public class AlquimiaLab {
    public static final String MODID = "alquimialab";

    public AlquimiaLab() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModTabs.TABS.register(modBus);
    }
}
