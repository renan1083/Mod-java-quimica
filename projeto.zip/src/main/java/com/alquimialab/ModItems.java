package com.alquimialab;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, AlquimiaLab.MODID);

    public static final RegistryObject<Item> FERTILIZANTE_BASICO = ITEMS.register("fertilizante_basico",
        () -> new FertilizerItem(new Item.Properties(), FertilizerItem.Kind.BASICO));
    public static final RegistryObject<Item> FERTILIZANTE_POTENTE = ITEMS.register("fertilizante_potente",
        () -> new FertilizerItem(new Item.Properties(), FertilizerItem.Kind.POTENTE));
    public static final RegistryObject<Item> FERTILIZANTE_VERDEJANTE = ITEMS.register("fertilizante_verdejante",
        () -> new FertilizerItem(new Item.Properties(), FertilizerItem.Kind.VERDEJANTE));
    public static final RegistryObject<Item> FERTILIZANTE_HIDRATANTE = ITEMS.register("fertilizante_hidratante",
        () -> new FertilizerItem(new Item.Properties(), FertilizerItem.Kind.HIDRATANTE));
}
